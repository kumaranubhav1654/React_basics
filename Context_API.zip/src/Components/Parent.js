import React from "react";
import ChildComponent from "./Child";

export const MyContext = React.createContext();

const ParentComponent = () => {
  const [data, setData] = React.useState("Initial data");

  const updateData = (newValue) => {
    setData(newValue);
  };

  const contextValue = {
    data: data,
    updateData: updateData
  };

  return (
    <div>
      <h2>Parent Component</h2>
      <MyContext.Provider value={contextValue}>
        <ChildComponent />
      </MyContext.Provider>
    </div>
  );
};

export default ParentComponent;
