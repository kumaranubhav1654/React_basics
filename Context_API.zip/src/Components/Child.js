import React, { useContext, useState } from "react";
import { MyContext } from "./Parent";

const ChildComponent = () => {
  const context = useContext(MyContext);

  const [newData, setNewData] = useState(context.data);

  return (
    <div>
      <h2>Data:{context.data} </h2>
      <input
        onChange={(e) => {
          setNewData(e.target.value);
        }}
      ></input>
      <button onClick={() => context.updateData(newData)}>Update Data</button>
    </div>
  );
};

export default ChildComponent;
