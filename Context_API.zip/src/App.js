import "./styles.css";
import ParentComponent from "./Components/Parent";

export default function App() {
  return (
    <div className="App">
      <h1>Context API</h1>
      <ParentComponent />
    </div>
  );
}
